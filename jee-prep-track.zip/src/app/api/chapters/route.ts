import { db } from '@/lib/db'
import { getAuthUser, jsonResponse, errorResponse } from '@/lib/auth'
import type { ChapterWithProgress, ChapterStatus } from '@/lib/types'

export async function GET(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const chapters = await db.chapter.findMany({
    orderBy: [{ subject: 'asc' }, { grade: 'asc' }, { sortOrder: 'asc' }],
  })

  const progress = await db.chapterProgress.findMany({
    where: { userId: authUser.id },
  })

  const progressMap = new Map(progress.map((p) => [p.chapterId, p]))

  const result: ChapterWithProgress[] = chapters.map((c) => {
    const p = progressMap.get(c.id)
    return {
      id: c.id,
      subject: c.subject as ChapterWithProgress['subject'],
      grade: c.grade as 11 | 12,
      name: c.name,
      sortOrder: c.sortOrder,
      status: (p?.status as ChapterStatus) || 'incomplete',
      lastRevisedAt: p?.lastRevisedAt?.toISOString() || null,
      nextRevisionAt: p?.nextRevisionAt?.toISOString()?.slice(0, 10) || null,
      notes: p?.notes || null,
    }
  })

  return jsonResponse(result)
}
