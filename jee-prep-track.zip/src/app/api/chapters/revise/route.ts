import { db } from '@/lib/db'
import { getAuthUser, jsonResponse, errorResponse } from '@/lib/auth'
import { nextRevisionDate } from '@/lib/constants'

export async function POST(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const { chapterId } = await request.json()
  if (!chapterId) return errorResponse('chapterId required')

  const existing = await db.chapterProgress.findUnique({
    where: { userId_chapterId: { userId: authUser.id, chapterId } },
  })

  const now = new Date()
  const stage = existing?.lastRevisedAt ? 1 : 0

  await db.chapterProgress.upsert({
    where: { userId_chapterId: { userId: authUser.id, chapterId } },
    create: {
      userId: authUser.id,
      chapterId,
      status: 'revision',
      lastRevisedAt: now,
      nextRevisionAt: nextRevisionDate(now, stage),
    },
    update: {
      status: 'revision',
      lastRevisedAt: now,
      nextRevisionAt: nextRevisionDate(now, stage),
    },
  })

  return jsonResponse({ ok: true })
}
