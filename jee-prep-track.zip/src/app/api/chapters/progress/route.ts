import { db } from '@/lib/db'
import { getAuthUser, jsonResponse, errorResponse } from '@/lib/auth'
import { nextRevisionDate, type ChapterStatus } from '@/lib/constants'

export async function PUT(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const { chapterId, status } = await request.json()
  if (!chapterId || !status) return errorResponse('chapterId and status required')

  const now = new Date()
  const schedulesRevision = status === 'completed' || status === 'revision'

  await db.chapterProgress.upsert({
    where: { userId_chapterId: { userId: authUser.id, chapterId } },
    create: {
      userId: authUser.id,
      chapterId,
      status: status as ChapterStatus,
      lastRevisedAt: schedulesRevision ? now : null,
      nextRevisionAt: schedulesRevision ? nextRevisionDate(now, 0) : null,
    },
    update: {
      status: status as ChapterStatus,
      lastRevisedAt: schedulesRevision ? now : undefined,
      nextRevisionAt: schedulesRevision ? nextRevisionDate(now, 0) : null,
    },
  })

  return jsonResponse({ ok: true })
}
