import { db } from '@/lib/db'
import { getAuthUser, jsonResponse, errorResponse } from '@/lib/auth'

export async function PUT(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const { chapterId, notes } = await request.json()
  if (!chapterId) return errorResponse('chapterId required')

  await db.chapterProgress.upsert({
    where: { userId_chapterId: { userId: authUser.id, chapterId } },
    create: {
      userId: authUser.id,
      chapterId,
      status: 'incomplete',
      notes,
    },
    update: { notes },
  })

  return jsonResponse({ ok: true })
}
