import { db } from '@/lib/db'
import { getAuthUser, jsonResponse, errorResponse } from '@/lib/auth'

export async function GET(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)
  return jsonResponse(authUser)
}

export async function PUT(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const { name, targetYear, remindersEnabled } = await request.json()

  await db.user.update({
    where: { id: authUser.id },
    data: {
      ...(name !== undefined && { name }),
      ...(targetYear !== undefined && { targetYear }),
      ...(remindersEnabled !== undefined && { remindersEnabled }),
    },
  })

  return jsonResponse({
    ...authUser,
    ...(name !== undefined && { name }),
    ...(targetYear !== undefined && { targetYear }),
    ...(remindersEnabled !== undefined && { remindersEnabled }),
  })
}