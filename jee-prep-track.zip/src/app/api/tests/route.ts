import { db } from '@/lib/db'
import { getAuthUser, jsonResponse, errorResponse } from '@/lib/auth'
import type { TestWithSections, TestSection, Subject, TestType } from '@/lib/types'

export async function GET(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const tests = await db.test.findMany({
    where: { userId: authUser.id },
    orderBy: { testDate: 'desc' },
  })

  const sections = await db.testSection.findMany({
    where: { userId: authUser.id },
  })

  const sectionMap = new Map<string, TestSection[]>()
  for (const s of sections) {
    const arr = sectionMap.get(s.testId) ?? []
    arr.push({
      id: s.id,
      testId: s.testId,
      userId: s.userId,
      subject: s.subject as Subject,
      correct: s.correct,
      incorrect: s.incorrect,
      unattempted: s.unattempted,
      marks: s.marks,
      maxMarks: s.maxMarks,
    })
    sectionMap.set(s.testId, arr)
  }

  const result: TestWithSections[] = tests.map((t) => ({
    id: t.id,
    userId: t.userId,
    name: t.name,
    testType: t.testType as TestType,
    testDate: t.testDate,
    totalMarks: t.totalMarks,
    obtainedMarks: t.obtainedMarks,
    rank: t.rank,
    percentile: t.percentile,
    notes: t.notes,
    createdAt: t.createdAt.toISOString(),
    sections: sectionMap.get(t.id) ?? [],
  }))

  return jsonResponse(result)
}

export async function POST(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const {
    name, testType, testDate, totalMarks, obtainedMarks,
    rank, percentile, notes, sections,
  } = await request.json()

  if (!name || !testDate || totalMarks == null || obtainedMarks == null) {
    return errorResponse('name, testDate, totalMarks, obtainedMarks required')
  }

  const test = await db.test.create({
    data: {
      userId: authUser.id,
      name,
      testType: testType || 'Other',
      testDate,
      totalMarks,
      obtainedMarks,
      rank: rank ?? null,
      percentile: percentile ?? null,
      notes: notes || null,
    },
  })

  if (sections?.length > 0) {
    await db.testSection.createMany({
      data: sections.map((s: any) => ({
        testId: test.id,
        userId: authUser.id,
        subject: s.subject,
        correct: s.correct || 0,
        incorrect: s.incorrect || 0,
        unattempted: s.unattempted || 0,
        marks: s.marks || 0,
        maxMarks: s.maxMarks || 0,
      })),
    })
  }

  return jsonResponse({ id: test.id }, 201)
}

export async function DELETE(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const url = new URL(request.url)
  const id = url.searchParams.get('id')
  if (!id) return errorResponse('id required')

  await db.test.deleteMany({ where: { id, userId: authUser.id } })
  return jsonResponse({ ok: true })
}
