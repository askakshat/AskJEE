import { db } from '@/lib/db'
import { getAuthUser, jsonResponse, errorResponse } from '@/lib/auth'
import type { Schedule, Subject } from '@/lib/types'

export async function GET(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const rows = await db.schedule.findMany({
    where: { userId: authUser.id },
    orderBy: [{ scheduledDate: 'asc' }, { startTime: 'asc' }],
  })

  const result: Schedule[] = rows.map((r) => ({
    id: r.id,
    userId: r.userId,
    title: r.title,
    subject: r.subject as Schedule['subject'],
    scheduledDate: r.scheduledDate,
    startTime: r.startTime,
    endTime: r.endTime,
    notes: r.notes,
    isDone: r.isDone,
    createdAt: r.createdAt.toISOString(),
  }))

  return jsonResponse(result)
}

export async function POST(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const { title, subject, scheduledDate, startTime, endTime, notes } = await request.json()
  if (!title || !scheduledDate) return errorResponse('Title and date required')

  const row = await db.schedule.create({
    data: {
      userId: authUser.id,
      title,
      subject: subject || null,
      scheduledDate,
      startTime: startTime || null,
      endTime: endTime || null,
      notes: notes || null,
    },
  })

  return jsonResponse({ id: row.id }, 201)
}

export async function DELETE(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const url = new URL(request.url)
  const id = url.searchParams.get('id')
  if (!id) return errorResponse('id required')

  await db.schedule.deleteMany({ where: { id, userId: authUser.id } })
  return jsonResponse({ ok: true })
}

export async function PATCH(request: Request) {
  const authUser = await getAuthUser(request)
  if (!authUser) return errorResponse('Not authenticated', 401)

  const { id, isDone } = await request.json()
  if (!id) return errorResponse('id required')

  await db.schedule.updateMany({
    where: { id, userId: authUser.id },
    data: { isDone },
  })

  return jsonResponse({ ok: true })
}
