import { db } from '@/lib/db'
import { hashPassword, createToken, jsonResponse, errorResponse } from '@/lib/auth'

export async function POST(request: Request) {
  try {
    const { email, password, name } = await request.json()
    if (!email || !password) return errorResponse('Email and password required')
    if (password.length < 6) return errorResponse('Password must be at least 6 characters')

    const existing = await db.user.findUnique({ where: { email } })
    if (existing) return errorResponse('Email already registered', 409)

    const passwordHash = await hashPassword(password)
    const user = await db.user.create({
      data: { email, passwordHash, name: name || null },
      select: { id: true, email: true, name: true, targetYear: true, remindersEnabled: true },
    })

    const token = await createToken(user.id)
    return jsonResponse({ user, token }, 201)
  } catch (e: any) {
    return errorResponse(e.message || 'Signup failed', 500)
  }
}
