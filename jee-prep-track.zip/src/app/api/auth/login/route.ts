import { db } from '@/lib/db'
import { verifyPassword, createToken, jsonResponse, errorResponse } from '@/lib/auth'

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()
    if (!email || !password) return errorResponse('Email and password required')

    const user = await db.user.findUnique({ where: { email } })
    if (!user) return errorResponse('Invalid email or password', 401)

    const valid = await verifyPassword(password, user.passwordHash)
    if (!valid) return errorResponse('Invalid email or password', 401)

    const token = await createToken(user.id)
    return jsonResponse({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        targetYear: user.targetYear,
        remindersEnabled: user.remindersEnabled,
      },
      token,
    })
  } catch (e: any) {
    return errorResponse(e.message || 'Login failed', 500)
  }
}
