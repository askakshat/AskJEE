import { getAuthUser, errorResponse } from '@/lib/auth'

export async function GET(request: Request) {
  const user = await getAuthUser(request)
  if (!user) return errorResponse('Not authenticated', 401)
  return Response.json(user)
}
