import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

type Subject = 'Physics' | 'Chemistry' | 'Mathematics'

interface ChapterInput {
  subject: Subject
  grade: 11 | 12
  name: string
  sortOrder: number
}

const chapters: ChapterInput[] = [
  // Physics Class 11
  { subject: 'Physics', grade: 11, name: 'Units and Measurements', sortOrder: 1 },
  { subject: 'Physics', grade: 11, name: 'Kinematics', sortOrder: 2 },
  { subject: 'Physics', grade: 11, name: 'Laws of Motion', sortOrder: 3 },
  { subject: 'Physics', grade: 11, name: 'Work, Energy and Power', sortOrder: 4 },
  { subject: 'Physics', grade: 11, name: 'Rotational Motion', sortOrder: 5 },
  { subject: 'Physics', grade: 11, name: 'Gravitation', sortOrder: 6 },
  { subject: 'Physics', grade: 11, name: 'Properties of Matter', sortOrder: 7 },
  { subject: 'Physics', grade: 11, name: 'Thermodynamics', sortOrder: 8 },
  { subject: 'Physics', grade: 11, name: 'Kinetic Theory of Gases', sortOrder: 9 },
  { subject: 'Physics', grade: 11, name: 'Oscillations', sortOrder: 10 },
  { subject: 'Physics', grade: 11, name: 'Waves', sortOrder: 11 },

  // Physics Class 12
  { subject: 'Physics', grade: 12, name: 'Electrostatics', sortOrder: 12 },
  { subject: 'Physics', grade: 12, name: 'Current Electricity', sortOrder: 13 },
  { subject: 'Physics', grade: 12, name: 'Magnetic Effects of Current', sortOrder: 14 },
  { subject: 'Physics', grade: 12, name: 'Electromagnetic Induction', sortOrder: 15 },
  { subject: 'Physics', grade: 12, name: 'Alternating Current', sortOrder: 16 },
  { subject: 'Physics', grade: 12, name: 'Electromagnetic Waves', sortOrder: 17 },
  { subject: 'Physics', grade: 12, name: 'Ray Optics', sortOrder: 18 },
  { subject: 'Physics', grade: 12, name: 'Wave Optics', sortOrder: 19 },
  { subject: 'Physics', grade: 12, name: 'Dual Nature of Radiation & Matter', sortOrder: 20 },
  { subject: 'Physics', grade: 12, name: 'Atoms and Nuclei', sortOrder: 21 },
  { subject: 'Physics', grade: 12, name: 'Semiconductor Electronics', sortOrder: 22 },
  { subject: 'Physics', grade: 12, name: 'Communication Systems', sortOrder: 23 },

  // Chemistry Class 11
  { subject: 'Chemistry', grade: 11, name: 'Some Basic Concepts of Chemistry', sortOrder: 1 },
  { subject: 'Chemistry', grade: 11, name: 'Structure of Atom', sortOrder: 2 },
  { subject: 'Chemistry', grade: 11, name: 'Classification of Elements', sortOrder: 3 },
  { subject: 'Chemistry', grade: 11, name: 'Chemical Bonding and Molecular Structure', sortOrder: 4 },
  { subject: 'Chemistry', grade: 11, name: 'States of Matter', sortOrder: 5 },
  { subject: 'Chemistry', grade: 11, name: 'Thermodynamics', sortOrder: 6 },
  { subject: 'Chemistry', grade: 11, name: 'Equilibrium', sortOrder: 7 },
  { subject: 'Chemistry', grade: 11, name: 'Redox Reactions', sortOrder: 8 },
  { subject: 'Chemistry', grade: 11, name: 'Hydrogen', sortOrder: 9 },
  { subject: 'Chemistry', grade: 11, name: 's-Block Elements', sortOrder: 10 },
  { subject: 'Chemistry', grade: 11, name: 'p-Block Elements (Group 13-14)', sortOrder: 11 },
  { subject: 'Chemistry', grade: 11, name: 'p-Block Elements (Group 15-18)', sortOrder: 12 },
  { subject: 'Chemistry', grade: 11, name: 'Organic Chemistry — Some Basic Principles', sortOrder: 13 },
  { subject: 'Chemistry', grade: 11, name: 'Hydrocarbons', sortOrder: 14 },
  { subject: 'Chemistry', grade: 11, name: 'Environmental Chemistry', sortOrder: 15 },

  // Chemistry Class 12
  { subject: 'Chemistry', grade: 12, name: 'Solutions', sortOrder: 16 },
  { subject: 'Chemistry', grade: 12, name: 'Electrochemistry', sortOrder: 17 },
  { subject: 'Chemistry', grade: 12, name: 'Chemical Kinetics', sortOrder: 18 },
  { subject: 'Chemistry', grade: 12, name: 'Surface Chemistry', sortOrder: 19 },
  { subject: 'Chemistry', grade: 12, name: 'd- and f-Block Elements', sortOrder: 20 },
  { subject: 'Chemistry', grade: 12, name: 'Coordination Compounds', sortOrder: 21 },
  { subject: 'Chemistry', grade: 12, name: 'Haloalkanes and Haloarenes', sortOrder: 22 },
  { subject: 'Chemistry', grade: 12, name: 'Alcohols, Phenols and Ethers', sortOrder: 23 },
  { subject: 'Chemistry', grade: 12, name: 'Aldehydes, Ketones and Carboxylic Acids', sortOrder: 24 },
  { subject: 'Chemistry', grade: 12, name: 'Amines', sortOrder: 25 },
  { subject: 'Chemistry', grade: 12, name: 'Biomolecules', sortOrder: 26 },
  { subject: 'Chemistry', grade: 12, name: 'Polymers', sortOrder: 27 },
  { subject: 'Chemistry', grade: 12, name: 'Chemistry in Everyday Life', sortOrder: 28 },

  // Mathematics Class 11
  { subject: 'Mathematics', grade: 11, name: 'Sets', sortOrder: 1 },
  { subject: 'Mathematics', grade: 11, name: 'Relations and Functions', sortOrder: 2 },
  { subject: 'Mathematics', grade: 11, name: 'Trigonometric Functions', sortOrder: 3 },
  { subject: 'Mathematics', grade: 11, name: 'Mathematical Induction', sortOrder: 4 },
  { subject: 'Mathematics', grade: 11, name: 'Complex Numbers and Quadratic Equations', sortOrder: 5 },
  { subject: 'Mathematics', grade: 11, name: 'Linear Inequalities', sortOrder: 6 },
  { subject: 'Mathematics', grade: 11, name: 'Permutations and Combinations', sortOrder: 7 },
  { subject: 'Mathematics', grade: 11, name: 'Binomial Theorem', sortOrder: 8 },
  { subject: 'Mathematics', grade: 11, name: 'Sequences and Series', sortOrder: 9 },
  { subject: 'Mathematics', grade: 11, name: 'Straight Lines', sortOrder: 10 },
  { subject: 'Mathematics', grade: 11, name: 'Conic Sections', sortOrder: 11 },
  { subject: 'Mathematics', grade: 11, name: 'Limits and Derivatives', sortOrder: 12 },
  { subject: 'Mathematics', grade: 11, name: 'Mathematical Reasoning', sortOrder: 13 },
  { subject: 'Mathematics', grade: 11, name: 'Statistics', sortOrder: 14 },
  { subject: 'Mathematics', grade: 11, name: 'Probability', sortOrder: 15 },

  // Mathematics Class 12
  { subject: 'Mathematics', grade: 12, name: 'Relations and Functions', sortOrder: 16 },
  { subject: 'Mathematics', grade: 12, name: 'Inverse Trigonometric Functions', sortOrder: 17 },
  { subject: 'Mathematics', grade: 12, name: 'Matrices', sortOrder: 18 },
  { subject: 'Mathematics', grade: 12, name: 'Determinants', sortOrder: 19 },
  { subject: 'Mathematics', grade: 12, name: 'Continuity and Differentiability', sortOrder: 20 },
  { subject: 'Mathematics', grade: 12, name: 'Application of Derivatives', sortOrder: 21 },
  { subject: 'Mathematics', grade: 12, name: 'Integrals', sortOrder: 22 },
  { subject: 'Mathematics', grade: 12, name: 'Application of Integrals', sortOrder: 23 },
  { subject: 'Mathematics', grade: 12, name: 'Differential Equations', sortOrder: 24 },
  { subject: 'Mathematics', grade: 12, name: 'Vector Algebra', sortOrder: 25 },
  { subject: 'Mathematics', grade: 12, name: 'Three Dimensional Geometry', sortOrder: 26 },
  { subject: 'Mathematics', grade: 12, name: 'Linear Programming', sortOrder: 27 },
  { subject: 'Mathematics', grade: 12, name: 'Probability', sortOrder: 28 },
]

async function main() {
  console.log('Seeding JEE syllabus chapters...')
  const count = await db.chapter.count()
  if (count > 0) {
    console.log(`Already ${count} chapters exist. Skipping seed.`)
    return
  }

  for (const ch of chapters) {
    await db.chapter.create({ data: ch })
  }
  console.log(`Seeded ${chapters.length} chapters.`)
}

main()
  .catch(console.error)
  .finally(() => db.$disconnect())
